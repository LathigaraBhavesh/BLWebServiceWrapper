//
//  BLWebServiceWrapper.m
//
//  Created by Bhavesh Lathigara on 16/12/14.
//  Copyright (c) 2014 Bhavesh Lathigara. All rights reserved.
//

#import "BLWebServiceWrapper.h"

@implementation BLWebServiceWrapper
+(void)callAPIWithURLString:(NSString *)requestString success:(void(^)(id dict))successBlock failure:(void (^)(NSString *error))failureBlock
{
    NSString *urlString=requestString;
    NSLog(@"URL String = %@",urlString);
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL: url cachePolicy: NSURLRequestReloadIgnoringCacheData timeoutInterval:30.0];
    [urlRequest setHTTPMethod:@"POST"];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    [NSURLConnection sendAsynchronousRequest:urlRequest queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         if (error)
         {
             NSLog(@"Error,%@", [error localizedDescription]);
             failureBlock([error localizedDescription]);
         }
         else
         {
             NSError *errorJson;
             
             NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData:data options: NSJSONReadingMutableContainers error: &errorJson];
             
             data = nil;
             errorJson = nil;
             response = nil;
             error = nil;
             
             NSLog(@"Json = %@",JSON);
             
             dispatch_async(dispatch_get_main_queue(), ^{
                 successBlock(JSON);
             });
             JSON = nil;
         }
     }];
    urlString = nil;
    url = nil;
    urlRequest = nil;
    queue = nil;
    
}
+(void)callAPIWithImage:(UIImage *)image success:(void(^)(id dict))successBlock failure:(void (^)(NSString *error))failureBlock
{
    NSString *urlString=@"your url string with parameter";
    NSLog(@"URL String = %@",urlString);
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL: url cachePolicy: NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
    [urlRequest setHTTPMethod:@"POST"];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    NSData *imageData = UIImageJPEGRepresentation(image, 0.8);
    image = nil;
    NSString *charset = (NSString *)CFStringConvertEncodingToIANACharSetName(CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    
    NSString *boundary = @"0xKhTmLbOuNdArY";
    NSString *endBoundary = [NSString stringWithFormat:@"\r\n--%@\r\n", boundary];
    
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; charset=%@; boundary=%@", charset, boundary];
    [urlRequest addValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    NSMutableData *tempPostData = [NSMutableData data];
    [tempPostData appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Sample Key Value for data
    [tempPostData appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", @"photos"] dataUsingEncoding:NSUTF8StringEncoding]];
//    [[tempPostData appendData:@"Value_Param"] dataUsingEncoding:NSUTF8StringEncoding]];
    [tempPostData appendData:[endBoundary dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Sample file to send as data
    [tempPostData appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"photos\"; filename=\"%@\"\r\n", @".jpg"] dataUsingEncoding:NSUTF8StringEncoding]];
    [tempPostData appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [tempPostData appendData:imageData];
    [tempPostData appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [urlRequest setHTTPBody:tempPostData];
    tempPostData = nil;
    
    [NSURLConnection sendAsynchronousRequest:urlRequest queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         if (error)
         {
             NSLog(@"Error,%@", [error localizedDescription]);
             failureBlock([error localizedDescription]);
         }
         else
         {
             NSError *errorJson;
             
             NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData:data options: NSJSONReadingMutableContainers error: &errorJson];
             
             data = nil;
             errorJson = nil;
             response = nil;
             error = nil;
             
             NSLog(@"Json = %@",JSON);
             
             dispatch_async(dispatch_get_main_queue(), ^{
                 successBlock(JSON);
             });
             JSON = nil;
         }
     }];
    urlString = nil;
    url = nil;
    urlRequest = nil;
    queue = nil;
}
@end
