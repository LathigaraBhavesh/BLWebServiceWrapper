//
//  BLWebServiceWrapper.h
//
//  Created by Bhavesh Lathigara on 16/12/14.
//  Copyright (c) 2014 Bhavesh Lathigara. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BLWebServiceWrapper : NSObject

+(void)callAPIWithURLString:(NSString *)requestString success:(void(^)(id dict))successBlock failure:(void (^)(NSString *error))failureBlock;

+(void)callAPIWithImage:(UIImage *)image success:(void(^)(id dict))successBlock failure:(void (^)(NSString *error))failureBlock;

@end
